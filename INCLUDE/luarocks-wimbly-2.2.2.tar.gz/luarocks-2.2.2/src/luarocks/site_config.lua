local site_config = {}
site_config.LUAROCKS_PREFIX=[[/var/lib/nginx/luajit]]
site_config.LUA_INCDIR=[[/var/lib/nginx/luajit/include/luajit-2.1]]
site_config.LUA_LIBDIR=[[/var/lib/nginx/luajit/lib]]
site_config.LUA_BINDIR=[[/var/lib/nginx/luajit/bin]]
site_config.LUA_INTERPRETER=[[luajit]]
site_config.LUAROCKS_SYSCONFDIR=[[/var/lib/nginx/luajit/etc/luarocks]]
site_config.LUAROCKS_ROCKS_TREE=[[/var/lib/nginx/luajit]]
site_config.LUAROCKS_ROCKS_SUBDIR=[[/lib/luarocks/rocks]]
site_config.LUA_DIR_SET=true
site_config.LUAROCKS_UNAME_S=[[Linux]]
site_config.LUAROCKS_UNAME_M=[[x86_64]]
site_config.LUAROCKS_DOWNLOADER=[[curl]]
site_config.LUAROCKS_MD5CHECKER=[[md5sum]]
site_config.LUAROCKS_EXTERNAL_DEPS_SUBDIRS={ bin="bin", lib={ "lib", [[lib/x86_64-linux-gnu]] }, include="include" }
site_config.LUAROCKS_RUNTIME_EXTERNAL_DEPS_SUBDIRS={ bin="bin", lib={ "lib", [[lib/x86_64-linux-gnu]] }, include="include" }
return site_config
